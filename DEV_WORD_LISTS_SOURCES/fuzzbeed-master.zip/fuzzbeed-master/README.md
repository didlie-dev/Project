# fuzzbeed
28 Painful Truths Only Disney Princesses Will Understand

40 Superheroes Who Are Having A Really Rough Day

36 News Anchors Who Completely Screwed Up Their One Job

## More Info:
This was written in 36 hours at MHacks V

The site is visible here: http://fuzzbeed.me/ 

Even more info: http://challengepost.com/software/fuzzbeed

Facebook page: https://www.facebook.com/FuzzBeedOfficial
